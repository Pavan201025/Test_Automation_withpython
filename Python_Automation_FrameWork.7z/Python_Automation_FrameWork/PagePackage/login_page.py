import logging
import time
import UtilitiesPackage.custom_logger as cl
from selenium.webdriver.common.by import By
from TestBasePackage.selenium_driver import SeleniumDriver


class LoginPage(SeleniumDriver):
    log = cl.customLogger(logging.DEBUG)

    def __init__(self, driver):
        super().__init__(driver)
        self.driver = driver

    # Locators
    # _login_link = "Login"
    _username_field = "txtUserID"
    _password_field = "txtPassword"
    _login_button = "sub"

    def clickLoginLink(self):
        self.elementClick(self._login_link, locatorType="link")

    def enterUserName(self, username):
        self.sendKeys(username, self._username_field)

    def enterPassword(self, password):
        self.sendKeys(password, self._password_field)

    def clickLoginButton(self):
        time.sleep(3)
        self.elementClick(self._login_button, locatorType="id")

    def login(self, username, password):
        self.enterUserName(username)
        self.enterPassword(password)
        self.clickLoginButton()
